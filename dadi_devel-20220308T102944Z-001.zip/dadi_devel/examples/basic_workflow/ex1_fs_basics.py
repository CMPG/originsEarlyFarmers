# Dadi workflow example 1 - Creating a SFS and functions
import dadi

# Load data from a .vcf file
