from . import Demes

from .Demes import SFS
