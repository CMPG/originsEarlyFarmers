Ancient_Demographics2D_no_theta0.py
Module with the ancient demography model used in the paper.

1_fit_demography.py
Fit the early_growth_split_no_mig ancient demography model to the synonymous SFS.
Input:
    ancient_dfe/data/excoffier_Ancient10X.dd.syn.bpkl
Output:
    ancient_dfe/data/synonymous.fs
    ancient_dfe/results/demography_fits.txt

2_make_cache.py
Creates a cache of SFS with various levels of negative selection, which are integrated to make the DFE model SFS.
Should run on an HPC due to the amount of time this script can take.
Input:
    ancient_dfe/results/demography_fits.txt
Output:
    ancient_dfe/data/cache_2D.bpkl

3_fit_dfe.py
Fit a bivariate lognormal DFE to the nonsynonymous SFS.
Input:
    ancient_dfe/data/excoffier_Ancient10X.dd.non.bpkl
    ancient_dfe/data/cache_2D.bpkl
    ancient_dfe/results/demography_fits.txt
Output:
    ancient_dfe/data/nonsynonymous.fs
    ancient_dfe/results/dfe_fits.txt

4_paper_figures.py
Makes plots used in the paper.
Input:
    ancient_dfe/data/synonymous.fs
    ancient_dfe/data/excoffier_Ancient10X.dd.non.bpkl
Output:
    Option to save the plots.