1_make_popfile.py
Makes the file used to process the samples of interest from the VCF
Input: 
    None
Output: 
    ancient_dfe/data/Ancient.popfile

2_make_var_dd.py
Makes data dictionaries (which dadi uses to make the site frequency spectrum) using ANNOVAR exonic_variant_function output file to separate the synonymous and nonsynonymous entries.
Input:
    ancient_dfe/software/annovar/Ancient10X_08-2021_mergeAll102Labelled.exonic_variant_function
    ancient_dfe/data/Ancient10X_08-2021_mergeAll102Labelled.vcf
Output:
    ancient_dfe/data/Ancient10X_08-2021_mergeAll102Labelled.dd.bpkl
    ancient_dfe/data/excoffier_Ancient10X.dd.syn.bpkl
    ancient_dfe/data/excoffier_Ancient10X.dd.non.bpkl

3_get_ancestral_allele_dd.py
Add ancestral outgroup allele to data dictionaries.
Input:
    ancient_dfe/data/anc_genome_seq_dict.bpkl
    ancient_dfe/data/excoffier_Ancient10X.dd.syn.bpkl
    ancient_dfe/data/excoffier_Ancient10X.dd.non.bpkl
Output/Update:
    ancient_dfe/data/excoffier_Ancient10X.dd.syn.bpkl
    ancient_dfe/data/excoffier_Ancient10X.dd.non.bpkl
Note:
    If data/anc_genome_seq_dict.bpkl is not provided it will be made from either data/pos_2_anc_allele/anc_chrom_[1-22]_seq_dict.bpkl or the data/homo_sapiens_ancestor_GRCh37_e71 folder from Ensembl Compara for hg19 (http://ftp.ensembl.org/pub/release-71/fasta/ancestral_alleles/homo_sapiens_ancestor_GRCh37_e71.tar.bz2)