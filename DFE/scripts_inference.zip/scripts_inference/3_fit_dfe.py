'''
Fit a bivariate lognormal DFE to the nonsynonymous SFS.
'''

import pickle
import dadi
import random
import nlopt
import dadi.DFE as DFE 
import Ancient_Demographics2D_no_theta0 as AD2d

# Set seed for reproducing results
random.seed(12345)

# Load the nonsynonymous data dictionary
ddnon = pickle.load(open('../data/excoffier_Ancient10X.dd.non.bpkl','rb'))
# Define the populations of interest
pop_ids = ["neo_10x_pop", "modern_mainland_central_europe_pop"]
# Define the sample sizes we want for inference
ns = [16, 28]
# Make the SFS from the data dictionary
fs = dadi.Spectrum.from_data_dict(ddnon, pop_ids, ns, polarized=True)

# Save SFS
fs.to_file('../data/nonsynonymous.fs')

# Load cache of model SFS with selection
s2 = pickle.load(open('../data/cache_2D.bpkl','rb'))

# Define the distribution model for the DFE
sel_dist2d = DFE.PDFs_c.biv_lognormal

# Starting parameters for DFE inference
params = [3, 3, 0.5]
# Define the boundaries for the DFE parameter space
lb, ub = [1,1,0.1], [10,10,0.999]

# Misidentification parameter gets infered to be essentially 0,
# so we don't need to have it as a parameter.

# Get the theta value of the best fit theta.
fi = open('../results/demography_fits.txt','r').readlines()
ll_best = -1000000
for line in fi:
	ll = float(line.split('_')[1])
	if ll > ll_best:
		theta0 = float(line.split('_')[3])
		ll_best = ll

# Adjust theta for the higher proportion of nonsynonymous mutations
theta_ns = theta0*2.31

# DFE inference
# Save best fit parameters to a file
fi = open('../results/dfe_fits.txt','w')

# We want multiple starting points for parameters (line 93)
# So we do multiple optimizations to see if the different
# starting points arrive at very similar set of parameters.
for i in range(20):
	p0 = dadi.Misc.perturb_params(params, fold = 1, lower_bound=lb, upper_bound=ub)
	popt,_ = dadi.Inference.opt(p0, fs, s2.integrate, pts=None,
					func_args=[sel_dist2d, theta_ns],
					algorithm=nlopt.LN_BOBYQA, ftol_abs=0, maxeval=500,
					lower_bound=lb, upper_bound=ub,
					verbose=100, multinom=False)
	model = s2.integrate(popt, ns, sel_dist2d, theta_ns, None)
	ll = dadi.Inference.ll(model, fs)
	fi.write('ll_%.5f_params' %tuple([ll]))
	fi.write('_%.4f'*len(popt) %tuple(popt))
	fi.write('\n')
fi.close()