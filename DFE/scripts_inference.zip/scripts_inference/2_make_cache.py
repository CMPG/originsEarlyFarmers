'''
Creates a cache of SFS with various levels of negative selection, which are integrated together to make the DFE model fit to the nonsynonymous SFS.
'''

import dadi
from dadi.DFE import *
import pickle
import Ancient_Demographics2D_no_theta0 as AD2d

# Define sample sizes and grid points
ns = [16, 28]
pts_l = [max(ns)+(i+10)*10 for i in range(3)]


# Get the best fit parameters
fi = open('../results/demography_fits.txt','r').readlines()
ll_best = -1000000
for line in fi:
	ll = float(line.split('_')[1])
	if ll > ll_best:
		params = [float(ele) for ele in line.split('_')[5:-1]]
		ll_best = ll
		print(ll, params)

# Define model with selection
demo_sel = AD2d.early_growth_split_no_mig_sel

# Make the joint selection cache
s2 = Cache2D(params, ns, demo_sel, pts=pts_l, gamma_bounds=(1e-4,2000), gamma_pts=50, cpus=94, verbose=10, mp=True)
fid_name = open('../data/cache_2D.bpkl','wb')
pickle.dump(s2, fid_name, 2)
fid_name.close()




