'''
Generate plots for the demography and DFE inferences.
'''

import pickle, numpy as np
import dadi
import Ancient_Demographics2D_no_theta0 as Ancient_Demographics2D_no_theta0
models = Ancient_Demographics2D_no_theta0

demo_model = 'early_growth_split_no_mig'

pdemo = {'early_growth_split_no_mig': [0.1133, 1.4218, 0.1061, 0.0054, 0.0232, 0.0634]
         }[demo_model]
func = eval('models.{0}'.format(demo_model))
func_ex = dadi.Numerics.make_anc_state_misid_func(dadi.Numerics.make_extrap_func(func))

s2 = pickle.load(open('../data/cache_2D.bpkl', 'rb'))

# Double-check parameter values
assert(np.allclose(s2.params, pdemo[:-1]))

data_syn = dadi.Spectrum.from_file('../data/synonymous.fs')
ddnon = pickle.load(open('../data/excoffier_Ancient10X.dd.non.bpkl','rb'))
data_non = dadi.Spectrum.from_data_dict(ddnon, data_syn.pop_ids, projections=data_syn.sample_sizes, polarized=True)

model_syn = func_ex(pdemo, data_syn.sample_sizes, [128,138,148])
theta_syn = dadi.Inference.optimal_sfs_scaling(model_syn, data_syn)
model_syn *= theta_syn
ll = dadi.Inference.ll(model_syn, data_syn)
print("ll: synonymous", ll)
resid_syn = dadi.Inference.Anscombe_Poisson_residual(model_syn, data_syn)

model_non = s2.integrate([3.2949, 2.6136, 0.9968], None, dadi.DFE.PDFs.biv_lognormal, theta_syn*2.31, pts=None)
ll = dadi.Inference.ll(model_non, data_non)
print("ll: nonsynonymous", ll)
resid_non = dadi.Inference.Anscombe_Poisson_residual(model_non, data_non)

vmax = max(model_syn.max(), data_syn.max(), data_non.max())
vmin = 1e-3 

resid_syn.mask = (model_syn < vmin) | (data_syn < vmin)
resid_non.mask = (model_non < vmin) | (data_non < vmin)

pop_ids = ['ancient', 'modern']

import matplotlib.pyplot as plt
fig = plt.figure(2, figsize=(6.5,3))
fig.clear()
ax = fig.add_subplot(2, 4, 2)
dadi.Plotting.plot_single_2d_sfs(data_syn, vmin, vmax, ax=ax, colorbar=False, pop_ids=pop_ids)
ax = fig.add_subplot(2, 4, 3)
dadi.Plotting.plot_single_2d_sfs(model_syn, vmin, vmax, ax=ax, colorbar=True, pop_ids=pop_ids, extend='min')
ax = fig.add_subplot(2, 4, 4)
dadi.Plotting.plot_2d_resid(resid_syn, resid_range=3, ax=ax, pop_ids=pop_ids, extend="both")

ax = fig.add_subplot(2, 4, 6)
dadi.Plotting.plot_single_2d_sfs(data_non, vmin, vmax, ax=ax, colorbar=False, pop_ids=pop_ids)
ax = fig.add_subplot(2, 4, 7)
dadi.Plotting.plot_single_2d_sfs(model_non, vmin, vmax, ax=ax, colorbar=False, pop_ids=pop_ids)
ax = fig.add_subplot(2, 4, 8)
dadi.Plotting.plot_2d_resid(resid_non, resid_range=3, ax=ax, pop_ids=pop_ids, colorbar=False)

fig.tight_layout()

plt.show()
