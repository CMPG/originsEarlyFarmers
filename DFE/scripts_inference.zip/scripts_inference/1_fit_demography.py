'''
Fit the early_growth_split_no_mig ancient demography model
'''

import pickle
import dadi
import random
import nlopt
import Ancient_Demographics2D_no_theta0 as AD2d

# Set seed for reproducing results
random.seed(12345)

# Load the synonymous data dictionary
ddsyn = pickle.load(open('../data/excoffier_Ancient10X.dd.syn.bpkl','rb'))
# Define the populations of interest
pop_ids = ["neo_10x_pop", "modern_mainland_central_europe_pop"]
# Define the sample sizes we want for inference
ns = [16, 28]
# Make the SFS from the data dictionary
fs = dadi.Spectrum.from_data_dict(ddsyn, pop_ids, ns, polarized=True)

# Save SFS
fs.to_file('../data/synonymous.fs')

# Define starting parameters for demographic inference
params = [.1,1,0.1,0.005,0.01]

# Define the boundaries for the parameter space
lb , ub = [1e-4,1e-4, 1e-4, 1e-4, 1e-4], [100, 100, 10, 10, 10]

# Get demographic model
demo_model =  AD2d.early_growth_split_no_mig
func_ex = dadi.Numerics.make_extrap_func(dadi.Numerics.make_anc_state_misid_func(demo_model))

# Add on misidentification parameter and boundaries
params += [0.05]
lb += [1e-5]
ub += [1]

# Define grid points for extrapolation
pts_l = [max(ns)+(i+10)*10 for i in range(3)]

# Demography inference
# Save best fit parameters to a file
fi = open('../results/demography_fits.txt','w')

# We want multiple starting points for parameters (line 84)
# So we do multiple optimizations to see if the different
# starting points arrive at very similar set of parameters.
for i in range(20):
	p0 = dadi.Misc.perturb_params(params, fold = 0.5, lower_bound=lb, upper_bound=ub)
	popt,_ = dadi.Inference.opt(p0, fs, func_ex, pts_l,
						algorithm=nlopt.LN_BOBYQA, ftol_abs=0, xtol_abs=1e-10,maxeval=500,
						lower_bound=lb, upper_bound=ub,
						verbose=100, multinom=True)
	model = func_ex(popt, ns, pts_l)
	ll = dadi.Inference.ll_multinom(model, fs)
	theta = dadi.Inference.optimal_sfs_scaling(model,fs)
	fi.write('ll_%.5f_theta0_%.5f_params' %tuple([ll, theta]))
	fi.write('_%.4f'*len(popt) %tuple(popt))
	fi.write('\n')
fi.close()