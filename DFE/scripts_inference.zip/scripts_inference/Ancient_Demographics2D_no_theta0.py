"""
Two population demographic models for a modern population and an ancestral population.
"""
import numpy

from dadi import Numerics, PhiManip, Integration, Misc
from dadi.Spectrum_mod import Spectrum

import os

def early_growth_split_no_mig(params, ns, pts):
    nu_bot,nu_F,Tbefore,Tsplit, Tfinal = params

    xx = Numerics.default_grid(pts)

    phi = PhiManip.phi_1D(xx)

    nu_func = lambda t: nu_bot * (nu_F/nu_bot)**(t/(Tbefore + Tsplit + Tfinal))
    phi = Integration.one_pop(phi, xx, Tbefore, nu_func)
    phi = PhiManip.phi_1D_to_2D(xx, phi)
    phi = Integration.two_pops(phi, xx, Tbefore+Tsplit, nu_func, nu_func, initial_t=Tbefore)
    phi = Integration.two_pops(phi, xx, Tbefore+Tsplit+Tfinal, 1, nu_func, initial_t=Tbefore+Tsplit,
                               frozen1=True)

    fs = Spectrum.from_phi(phi, ns, (xx,xx))
    return fs

def early_growth_split_no_mig_sel(params, ns, pts):
    nu_bot,nu_F,Tbefore,Tsplit, Tfinal, gamma1, gamma2 = params

    xx = Numerics.default_grid(pts)

    phi = PhiManip.phi_1D(xx, gamma=gamma1)

    nu_func = lambda t: nu_bot * (nu_F/nu_bot)**(t/(Tbefore + Tsplit + Tfinal))
    phi = Integration.one_pop(phi, xx, Tbefore, nu_func, gamma=gamma1)
    phi = PhiManip.phi_1D_to_2D(xx, phi)
    phi = Integration.two_pops(phi, xx, Tbefore+Tsplit, nu_func, nu_func, initial_t=Tbefore, gamma1=gamma1, gamma2=gamma2)
    phi = Integration.two_pops(phi, xx, Tbefore+Tsplit+Tfinal, 1, nu_func, initial_t=Tbefore+Tsplit,
                               frozen1=True, gamma1=gamma1, gamma2=gamma2)

    fs = Spectrum.from_phi(phi, ns, (xx,xx))
    return fs

def early_growth_split_no_mig_single_sel(params, ns, pts):
    """
    """
    nu_bot,nu_F,Tbefore,Tsplit, Tfinal, gamma = params
    return early_growth_split_no_mig_sel([nu_bot,nu_F,Tbefore,Tsplit, Tfinal,gamma,gamma], ns, pts)


