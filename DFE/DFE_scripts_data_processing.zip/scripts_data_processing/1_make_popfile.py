'''
Make popfile that defines which samples belong to which population of interest.
'''

# Define the modern samples
europe_mainland_central_hgdp = [
"Polish-1",
"Bergamo-2",
"Bergamo-1",
"Czech-2",
"French-2",
"French-3",
"French-1",
"Hungarian-2",
"Hungarian-1",
"Greek-2",
"Greek-1",
"Albanian-1",
"Bulgarian-2",
"Bulgarian-1",
"Turkish-2",
"Turkish-1"
]

# Define the ancient samples
neo_10x_list = ['AKT16', 'BAR25', 'Nea3', 'Nea2', 'LEPE48', 'LEPE52', 'STAR1',
'VC3_2', 'Asp6', 'Klein7', 'Dil16', 'Ess7', 'Herx', 'WC1']

# Make the popfile
fid = open('../data/Ancient.popfile','w')

for sample in europe_mainland_central_hgdp:
	fid.write( '\t'.join([sample,"modern_mainland_central_europe_pop"]) + '\n' )

for sample in neo_10x_list:
	fid.write( '\t'.join([sample,"neo_10x_pop"]) + '\n' )

fid.close()