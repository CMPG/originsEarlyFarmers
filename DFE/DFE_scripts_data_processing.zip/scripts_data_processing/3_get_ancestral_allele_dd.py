'''
Add ancestral outgroup allele to data dictionaries.
'''

import pickle

print('loading data dicts')
ddsyn = pickle.load(open('../data/excoffier_Ancient10X.dd.syn.bpkl','rb'))
ddnon = pickle.load(open('../data/excoffier_Ancient10X.dd.non.bpkl','rb'))
print('finish loading dicts')

chroms = list(range(1,23))
chroms = [str(ele) for ele in chroms]

# Go through the chromosomes and converte the
# fasta files into text stings for ease of parsing
# the chromosome.
# Then add outgroup information into the data dictionaries.
try:
	print('loading sequences')
	genome_fa = pickle.load(open('../data/anc_genome_seq_dict.bpkl','rb'))
	print('finish loading sequences')
except:
	for chrom in chroms:
		print(chrom)
		# Check if chromosome dictionaries can
		# be loaded and if not generate them.
		try:
			chrom_fa = pickle.load(open('../data/pos_2_anc_allele/anc_chrom_'+chrom+'_seq_dict.bpkl','rb'))
		except:
			chrom_fa = {}
			fi_AA = open('../data/homo_sapiens_ancestor_GRCh37_e71/homo_sapiens_ancestor_'+chrom+'.fa','r').readlines()
			print('Num of lines: '+str(len(fi_AA)))
			chrom_fa[chrom] = ''
			for line in fi_AA:
				if line.startswith('>') != True:
					chrom_fa[chrom] += line.strip()
			pick = open('../data/pos_2_anc_allele/anc_chrom_'+chrom+'_seq_dict.bpkl','wb')
			pickle.dump(chrom_fa,pick,2)
			pick.close()

	# Make full dictionary of chromosome to sequence
	genome_fa = {}
	for chrom in chroms:
		chrom_fa = pickle.load(open('../data/pos_2_anc_allele/anc_chrom_'+chrom+'_seq_dict.bpkl','rb'))
		genome_fa[chrom] = chrom_fa[chrom]
	# Save full genome sequence dictionary
	pick = open('../data/anc_genome_seq_dict.bpkl','wb')
	pickle.dump(genome_fa,pick,2)
	pick.close()

print('Add ancestral alleles to dd')
for dd in [ddsyn, ddnon]:
	for key in dd:
		chrom_dd, pos = key.split('_')
		aa = genome_fa[chrom_dd][int(pos)-1].upper()
		if aa not in ['A','C','G','T']:
			aa='-'
		dd[key]['outgroup_allele'] = aa
		dd[key]['outgroup_context'] = '-'+aa+'-'

print('Save the updated data dictionaries.')
pick = open('../data/excoffier_Ancient10X.dd.syn.bpkl','wb')
pickle.dump(ddsyn, pick, 2)
pick.close()

pick = open('../data/excoffier_Ancient10X.dd.non.bpkl','wb')
pickle.dump(ddnon, pick, 2)
pick.close()










