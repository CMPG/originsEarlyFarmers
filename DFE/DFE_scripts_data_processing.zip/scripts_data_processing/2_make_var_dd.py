'''
Make data dictionaries, which dadi can convert into SFS, based on ANNOVAR synonymous and nonsynonymous annotation.
'''


import pickle
import dadi

# Parse the exonic_variant_function output file gotten
# from running ANNOVAR to catagorize which SNPs are
# synonymous and nonsynonymous.
syn_pos_list = []
non_pos_list = []
var_fid = open('../software/annovar/Ancient10X_08-2021_mergeAll102Labelled.exonic_variant_function')
for line in var_fid:
	var = line.split('\t')[1]
	pos = '_'.join([line.split('\t')[-5],line.split('\t')[-4]])
	if 'nonsynonymous' in var:
		non_pos_list.append(pos)
	elif 'synonymous' in var:
		syn_pos_list.append(pos)
var_fid.close()

# Attempt to load saved data dictionary made from the VCF.
# Making the data dictionary is a very memory instensive step
# so having it saved helps with convience incase you run out
# of memory and the script crashes. It is large so you
# might want to delete it after running this script.
try:
	dd = pickle.load(open('../data/Ancient10X_08-2021_mergeAll102Labelled.dd.bpkl','rb'))
except:
	dd = dadi.Misc.make_data_dict_vcf('../data/Ancient10X_08-2021_mergeAll102Labelled.vcf', '../data/Ancient.popfile')
	pick = open('../data/Ancient10X_08-2021_mergeAll102Labelled.dd.bpkl','wb')
	pickle.dump(dd, pick, 2)
	pick.close()

# Make new data dictionaries based on synonymous
# and nonsynonymous annotation.
dd_syn = {}
dd_non = {}

for pos in syn_pos_list:
	dd_syn[pos] = dd[pos]

for pos in non_pos_list:
	dd_non[pos] = dd[pos]

# Save the new data dictionaries.
pick = open('../data/excoffier_Ancient10X.dd.syn.bpkl','wb')
pickle.dump(dd_syn, pick, 2)
pick.close()

pick = open('../data/excoffier_Ancient10X.dd.non.bpkl','wb')
pickle.dump(dd_non, pick, 2)
pick.close()













